package com.SpringBootEMS_API.SpringBoo_EMS_API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBooEmsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBooEmsApiApplication.class, args);
		System.out.println("SpringBoot....");
	}

}
