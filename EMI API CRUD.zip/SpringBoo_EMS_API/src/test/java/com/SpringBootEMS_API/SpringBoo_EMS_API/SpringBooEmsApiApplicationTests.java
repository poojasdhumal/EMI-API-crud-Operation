package com.SpringBootEMS_API.SpringBoo_EMS_API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBooEmsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
